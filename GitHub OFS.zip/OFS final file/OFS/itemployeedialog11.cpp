#include "itemployeedialog11.h"
#include "ui_itemployeedialog11.h"
#include <QMessageBox>  // For showing message boxes

itemployeedialog11::itemployeedialog11(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::itemployeedialog11)
{
    ui->setupUi(this);
    itEmployeePages=nullptr;
    // Connect the buttons to their respective slots
    connect(ui->pushButtonITEmployeeLogin, &QPushButton::clicked, this, &itemployeedialog11::onLoginButtonClicked);
    connect(ui->pushButtonITEmployeeCancel, &QPushButton::clicked, this, &itemployeedialog11::onCancelButtonClicked);
}

itemployeedialog11::~itemployeedialog11()
{
    delete ui;
    if (itEmployeePages) {
        delete itEmployeePages;  // Clean up IT Head page
    }
}

void itemployeedialog11::onLoginButtonClicked()
{
    QString username = ui->lineEditITEmployeeUsername->text();
    QString password = ui->lineEditITEmployeePassword->text();

    // Check if username and password are correct
    if (username == "admin" && password == "1234") {
        // Create and show the IT Head page
        itEmployeePages = new itemployeepages(this);  // Initialize the IT Head page
        itEmployeePages->show();  // Show the IT Head page
    } else {

    }
}

void itemployeedialog11::onCancelButtonClicked()
{
    // Close the dialog without accepting the login
    reject();  // This closes the dialog and returns QDialog::Rejected
}

void itemployeedialog11::on_pushButtonLogin_2_clicked()
{
       this->close();
}

