#include "filehandler.h"
#include "ui_filehandler.h"

filehandler::filehandler(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::filehandler)
{
    ui->setupUi(this);
}

filehandler::~filehandler()
{
    delete ui;
}
