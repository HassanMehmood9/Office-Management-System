#ifndef MARKETINGEMPLOYEEDIALOG_H
#define MARKETINGEMPLOYEEDIALOG_H

#include <QDialog>
#include"marketingemployeepages.h"
namespace Ui {
class marketingemployeedialog;
}

class marketingemployeedialog : public QDialog
{
    Q_OBJECT

public:
    explicit marketingemployeedialog(QWidget *parent = nullptr);
    ~marketingemployeedialog();

private slots:
    // Slot for handling the login button click
    void onLoginButtonClicked();

    // Slot for handling the cancel button click
    void onCancelButtonClicked();

    void on_pushButtonLogin_3_clicked();

private:
    Ui::marketingemployeedialog *ui;  // Pointer to the UI
    marketingemployeepages* MarketingEmployeePages;
};

#endif // MARKETINGEMPLOYEEDIALOG_H
