#include "marketingemployeedialog.h"
#include "ui_marketingemployeedialog.h"
#include <QMessageBox>  // For message box

marketingemployeedialog::marketingemployeedialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::marketingemployeedialog)
{
    ui->setupUi(this);
    MarketingEmployeePages=nullptr;
    // Connect the login button to the corresponding slot
    connect(ui->pushButtonMarketingEmployeeLogin, &QPushButton::clicked, this, &marketingemployeedialog::onLoginButtonClicked);

    // Connect the cancel button to the corresponding slot
    connect(ui->pushButtonMarketingEmployeeCancel, &QPushButton::clicked, this, &marketingemployeedialog::onCancelButtonClicked);
}

marketingemployeedialog::~marketingemployeedialog()
{
    delete ui;
    if (MarketingEmployeePages) {
        delete MarketingEmployeePages;  // Clean up IT Head page
    }
}

void marketingemployeedialog::onLoginButtonClicked()
{
    // Get the username and password entered by the user
    QString username = ui->lineEditMarketingEmployeeUsername->text();
    QString password = ui->lineEditMarketingEmployeePassword->text();

    // Check if the username and password match the correct credentials (example: admin/1234)
    if (username == "admin" && password == "1234") {
        // Create and show the IT Head page
        MarketingEmployeePages = new marketingemployeepages(this);  // Initialize the IT Head page
        MarketingEmployeePages->show();  // Show the IT Head page
    } else {
    }
}

void marketingemployeedialog::onCancelButtonClicked()
{
    // Reject the dialog if the cancel button is clicked
    reject();
}

void marketingemployeedialog::on_pushButtonLogin_3_clicked()
{
    this->close();
}

