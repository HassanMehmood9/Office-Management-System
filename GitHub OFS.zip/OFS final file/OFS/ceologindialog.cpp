#include "ceologindialog.h"
#include "ui_ceologindialog.h"
#include <QMessageBox>

CeoLoginDialog::CeoLoginDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CeoLoginDialog)
{
    ui->setupUi(this);

    // Connect the login button to the slot
    connect(ui->loginButton, &QPushButton::clicked, this, &CeoLoginDialog::onLoginClicked);
}

CeoLoginDialog::~CeoLoginDialog()
{
    delete ui;
}

void CeoLoginDialog::onLoginClicked()
{
    QString username = ui->usernameEdit->text();
    QString password = ui->passwordEdit->text();

    if (username == "admin" && password == "admin") {
        QMessageBox::information(this, "Login", "Welcome, CEO!");
        accept(); // Close dialog with success
    } else {
        QMessageBox::critical(this, "Login Error", "Incorrect username or password.");
    }
}
