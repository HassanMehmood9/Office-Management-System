#ifndef MARKETINGHEADPAGE_H
#define MARKETINGHEADPAGE_H

#include <QDialog>
#include <QTableView>
#include <QStandardItemModel>
#include <QPushButton>

namespace Ui {
class marketingheadpage;
}

class marketingheadpage : public QDialog
{
    Q_OBJECT

public:
    explicit marketingheadpage(QWidget *parent = nullptr);
    ~marketingheadpage();

private slots:
    void onAddEmployeeClicked();
    void onRemoveEmployeeClicked();
    void onAssignTaskClicked();
    void onViewTaskClicked();

  void on_pushButtonLogin_2_clicked();


private:
    void adjustTableColumns();
    void saveEmployeeData();
    void loadEmployeeData();

    Ui::marketingheadpage *ui;
    QTableView *employeeTable;
    QStandardItemModel *model;
    int rowCount;
};

#endif // MARKETINGHEADPAGE_H
