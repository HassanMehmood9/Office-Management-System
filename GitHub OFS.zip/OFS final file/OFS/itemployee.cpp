#include "itemployee.h"

itEmployee::itEmployee() {}
