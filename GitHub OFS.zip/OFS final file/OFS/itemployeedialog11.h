#ifndef ITEMPOYEEDIALOG11_H
#define ITEMPOYEEDIALOG11_H

#include <QDialog>
#include "itemployeepages.h"

namespace Ui {
class itemployeedialog11;
}

class itemployeedialog11 : public QDialog
{
    Q_OBJECT

public:
    explicit itemployeedialog11(QWidget *parent = nullptr);
    ~itemployeedialog11();

private slots:
    // Slot for handling the login button click
    void onLoginButtonClicked();

    // Slot for handling the cancel button click
    void onCancelButtonClicked();

    void on_pushButtonLogin_2_clicked();

private:
    Ui::itemployeedialog11 *ui;  // Pointer to the UI
    itemployeepages* itEmployeePages;
};

#endif // ITEMPOYEEDIALOG11_H
