#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDialog>
#include <QStandardItemModel>  // Include QStandardItemModel
#include <QTableView>  // Include QTableView for displaying employee table

// Include the dialog headers
#include "ceodialog11.h"  // Include CEO dialog
#include "marketingheaddialog11.h"  // Include Marketing Head dialog
#include "itheaddialog11.h"  // Include IT Head dialog
#include "itemployeedialog11.h"  // Include IT Employee dialog
#include "marketingemployeedialog.h"  // Include Marketing Employee dialog
#include "assigntaskdialog.h"  // Include Assign Task dialog header
#include "ceopage.h"
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onOkButtonClicked();
    void onAssignTaskClicked();  // Declare slot for Assign Task button
    void setupEmployeeTable();  // Declare the setupEmployeeTable function here

private:
    Ui::MainWindow *ui;
    QStandardItemModel *employeeModel;  // Model for employee data
    // Declare the template function (no need to instantiate it here)
    template <typename DialogType>
    void handleLogin(const QString &role);
};

#endif // MAINWINDOW_H
