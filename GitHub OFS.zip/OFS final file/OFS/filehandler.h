#ifndef FILEHANDLER_H
#define FILEHANDLER_H

#include <QString>
#include <QList>
#include "Employee.h"  // Include the Employee class

class filehandler {
public:
    // Static functions to read and write employee data
    static QList<Employee> readEmployeeDataFromFile();
    static void writeEmployeeDataToFile(const QList<Employee>& employeeList);
};

#endif // FILEHANDLER_H
