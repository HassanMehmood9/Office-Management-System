#ifndef ASSIGNTASKDIALOG_H
#define ASSIGNTASKDIALOG_H

#include <QDialog>

namespace Ui {
class assigntaskdialog;
}

class assigntaskdialog : public QDialog
{
    Q_OBJECT

public:
    explicit assigntaskdialog(QWidget *parent = nullptr);
    ~assigntaskdialog();

    // Function to populate the employee name in the read-only field
    void setEmployeeName(const QString &name);

private slots:
    void onSaveTaskClicked();    // Slot for Save button
    void onCancelTaskClicked();  // Slot for Cancel button

private:
    Ui::assigntaskdialog *ui;
};

#endif // ASSIGNTASKDIALOG_H
