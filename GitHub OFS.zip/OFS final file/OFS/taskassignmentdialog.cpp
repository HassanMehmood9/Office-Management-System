#include "taskassignmentdialog.h"
#include "ui_taskassignmentdialog.h"
#include <QMessageBox>

TaskAssignmentDialog::TaskAssignmentDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::TaskAssignmentDialog)
{
    ui->setupUi(this);
}

TaskAssignmentDialog::~TaskAssignmentDialog()
{
    delete ui;
}

void TaskAssignmentDialog::on_submitButton_clicked()
{
    // Logic to handle task submission
    QString taskDescription = ui->taskDescriptionLineEdit->text();
    QString employeeName = ui->employeeComboBox->currentText();

    if (!taskDescription.isEmpty() && !employeeName.isEmpty()) {
        // Task submission logic here
        // You can add the logic to assign the task to the selected employee
        // For example, save the task in a file or database, or update the task status

        // Display a confirmation message in the status label
        ui->statusLabel->setText("Task assigned to " + employeeName);

        // Close the dialog when done
        accept();
    } else {
        // Show a warning if fields are empty
        QMessageBox::warning(this, "Input Error", "Please fill in all fields.");
    }
}
