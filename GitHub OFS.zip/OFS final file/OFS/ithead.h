#ifndef ITHEAD_H
#define ITHEAD_H

class ITHead
{
public:
    ITHead();
};

#endif // ITHEAD_H
