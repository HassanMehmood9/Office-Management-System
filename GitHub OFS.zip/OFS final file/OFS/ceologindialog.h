#ifndef CEOLOGINDIALOG_H
#define CEOLOGINDIALOG_H

#include <QDialog>

namespace Ui {
class CeoLoginDialog;
}

class CeoLoginDialog : public QDialog
{
    Q_OBJECT

public:
    explicit CeoLoginDialog(QWidget *parent = nullptr);
    ~CeoLoginDialog();

private slots:
    void onLoginClicked(); // Slot for login button

private:
    Ui::CeoLoginDialog *ui; // Pointer to the auto-generated UI class
};

#endif // CEOLOGINDIALOG_H
