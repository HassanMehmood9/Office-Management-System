#ifndef CEODIALOG11_H
#define CEODIALOG11_H

#include <QDialog>
#include <QMessageBox>

namespace Ui {
class ceodialog11;
}

class ceodialog11 : public QDialog
{
    Q_OBJECT

public:
    explicit ceodialog11(QWidget *parent = nullptr);
    ~ceodialog11();

private slots:
    void onLoginButtonClicked(); // Slot for Login button
    void onCancelButtonClicked(); // Slot for Cancel button

    void on_pushButtonLogin_2_clicked();

private:
    Ui::ceodialog11 *ui;
};

#endif // CEODIALOG11_H
