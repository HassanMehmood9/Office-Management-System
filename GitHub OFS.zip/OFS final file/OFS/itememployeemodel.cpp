#include "itememployeemodel.h"

ItemEmployeeModel::ItemEmployeeModel(QObject *parent)
    : QAbstractTableModel(parent)
{
    loadDataFromFile();  // Load employee data when the model is created
}

ItemEmployeeModel::~ItemEmployeeModel()
{
    saveDataToFile();  // Save employee data when the model is destroyed
}

int ItemEmployeeModel::rowCount(const QModelIndex &parent) const
{
    return employeeList.count();  // Return the number of employees
}

int ItemEmployeeModel::columnCount(const QModelIndex &parent) const
{
    return 3;  // Columns: Name, Employee ID, Department
}

QVariant ItemEmployeeModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || role != Qt::DisplayRole)
        return QVariant();

    const ItemEmployee &employee = employeeList.at(index.row());

    switch (index.column()) {
    case 0:
        return employee.name;
    case 1:
        return employee.employeeID;
    case 2:
        return employee.department;
    default:
        return QVariant();
    }
}

QVariant ItemEmployeeModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    if (role != Qt::DisplayRole)
        return QVariant();

    if (orientation == Qt::Horizontal) {
        switch (section) {
        case 0:
            return "Name";
        case 1:
            return "Employee ID";
        case 2:
            return "Department";
        default:
            return QVariant();
        }
    }

    return QVariant();
}

void ItemEmployeeModel::addEmployee(const ItemEmployee &employee)
{
    beginInsertRows(QModelIndex(), employeeList.count(), employeeList.count());  // Insert a new row
    employeeList.append(employee);  // Add employee to list
    endInsertRows();
    saveDataToFile();  // Save to file after adding an employee
}

void ItemEmployeeModel::removeEmployee(const QString &employeeID)
{
    for (int i = 0; i < employeeList.count(); ++i) {
        if (employeeList[i].employeeID == employeeID) {
            beginRemoveRows(QModelIndex(), i, i);  // Begin removing row
            employeeList.removeAt(i);  // Remove employee
            endRemoveRows();
            saveDataToFile();  // Save to file after removing an employee
            break;
        }
    }
}

void ItemEmployeeModel::saveDataToFile()
{
    QFile file("employees.txt");
    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&file);
        for (const ItemEmployee &employee : employeeList) {
            out << employee.name << "," << employee.employeeID << "," << employee.department << "\n";
        }
        file.close();
    }
}

void ItemEmployeeModel::loadDataFromFile()
{
    QFile file("employees.txt");
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        while (!in.atEnd()) {
            QString line = in.readLine();
            QStringList fields = line.split(",");
            if (fields.size() == 3) {
                ItemEmployee employee(fields[0], fields[1], fields[2]);
                employeeList.append(employee);
            }
        }
        file.close();
    }
}
