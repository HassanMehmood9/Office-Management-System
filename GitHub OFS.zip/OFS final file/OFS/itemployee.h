#ifndef ITEMPLOYEE_H
#define ITEMPLOYEE_H

class itEmployee
{
public:
    itEmployee();
};

#endif // ITEMPLOYEE_H
