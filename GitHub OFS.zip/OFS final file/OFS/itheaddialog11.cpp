#include "itheaddialog11.h"
#include "ui_itheaddialog11.h"

itheaddialog11::itheaddialog11(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::itheaddialog11)
{
    ui->setupUi(this);

    // Initialize the itheadpage pointer to null
    itHeadPage = nullptr;

    // Connect the login button to the onLoginButtonClicked slot
    connect(ui->pushButtonITLogin, &QPushButton::clicked, this, &itheaddialog11::onLoginButtonClicked);

    // Connect the cancel button to reject the dialog
    connect(ui->pushButtonITCancel, &QPushButton::clicked, this, &itheaddialog11::reject);
}

itheaddialog11::~itheaddialog11()
{
    delete ui;  // Clean up UI
    if (itHeadPage) {
        delete itHeadPage;  // Clean up IT Head page
    }
}

void itheaddialog11::onLoginButtonClicked()
{
    QString username = ui->lineEditITUsername->text();  // Get username
    QString password = ui->lineEditITPassword->text();  // Get password

    // Check if the username or password is empty
    if (username.isEmpty() || password.isEmpty()) {
        return;  // Simply return if any field is empty, without showing a message box
    }

    // Correct credentials for IT Head
    QString correctUsername = "admin";
    QString correctPassword = "1234";

    // If login is successful, open the IT Head page
    if (username == correctUsername && password == correctPassword) {
        // Remove accept(), no longer close the dialog immediately

        // Create and show the IT Head page
        itHeadPage = new itheadpage(this);  // Initialize the IT Head page
        itHeadPage->show();  // Show the IT Head page

        // Do NOT call close() here, so the login dialog stays open
    } else {
        // You can handle incorrect login here if necessary (without showing a message box)
    }
}

void itheaddialog11::on_pushButtonLogin_2_clicked()
{
    close();  // Close the login dialog
}
