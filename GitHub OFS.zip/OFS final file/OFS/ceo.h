#ifndef CEO_H
#define CEO_H

#include <QDialog>
#include "ui_ceologindialog.h"  // Include the auto-generated UI header here directly

class CeoLoginDialog : public QDialog
{
    Q_OBJECT

public:
    explicit CeoLoginDialog(QWidget *parent = nullptr);
    ~CeoLoginDialog();

private slots:
    void onLoginClicked();

private:
    Ui::CeoLoginDialog *ui; // Use the defined UI class here
};

#endif // CEO_H
