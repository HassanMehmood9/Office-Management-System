#ifndef MARKETINGHEAD_H
#define MARKETINGHEAD_H

class marketingHead
{
public:
    marketingHead();
};

#endif // MARKETINGHEAD_H
